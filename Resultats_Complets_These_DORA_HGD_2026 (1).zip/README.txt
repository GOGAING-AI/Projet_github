
==========================================================================
RÉSULTATS COMPLETS — THÈSE DE DOCTORAT EN MÉDECINE
Évaluation du jeûne préopératoire en chirurgie élective — HGD 2026
Étudiante : DORA [NOM DE FAMILLE] — 6ème Année
Faculté de Médecine — Université de Douala
==========================================================================

CONTENU DU DOSSIER
------------------

01_These_Word/
  └── Memoire_These_DORA_HGD_2026.docx
        Thèse de Doctorat en Médecine complète (≥85 pages)
        Inclut : Introduction, Revue de la littérature, Méthodologie,
                 Résultats avec figures, Discussion, Conclusion,
                 Références bibliographiques (43 refs), Annexes.

02_Scripts_Python/
  └── analyse_jeune_preop_v2.py
        Script Python complet (version corrigée et annotée)
        → Nettoyage des données, analyses descriptives (Obj.1–4),
          tests Mann-Whitney, Kruskal-Wallis, génération de 17 figures.
        Packages requis : pandas, numpy, matplotlib, seaborn, scipy, openpyxl

03_Scripts_R/
  └── analyse_jeune_preop.R
        Script R équivalent, commenté (tidyverse/ggplot2)
        → Mêmes analyses que Python + violin plots, heatmap viridis.
        Packages requis : ggplot2, dplyr, tidyr, scales, gridExtra,
                          RColorBrewer, viridis, readxl

04_Images_Python/  (17 figures haute résolution 150 dpi)
  00_dashboard.png        — Tableau de bord général (vue synthétique)
  01_sexe.png             — Répartition par sexe
  02_age.png              — Distribution des âges + groupes d'âge
  03_imc.png              — Distribution de l'IMC + catégories OMS
  04_asa.png              — Score ASA et âge moyen par score
  05_specialite.png       — Spécialité chirurgicale
  06_anesthesie.png       — Type d'anesthésie
  07_antecedents.png      — Antécédents opératoires
  08_distribution_jeune.png — Distribution jeûne vs recommandations
  09_boxplots_jeune.png   — Boxplots jeûne solide et liquide
  10_jeune_par_specialite.png — Durée par spécialité
  11_instructions.png     — Conformité instructions de jeûne
  12_source_instructions.png  — Source des instructions
  13_retard_chirurgical.png   — Retards chirurgicaux
  14_retard_par_specialite.png — Retards par spécialité
  15_heatmap_specialite_anesthesie.png — Heatmap
  16_comparaison_recommandations.png   — Observé vs recommandé

05_Images_R/  (20 figures haute résolution 150 dpi — ggplot2)
  R01_sexe.png            — Sexe (ggplot2)
  R02_age_histo.png       — Âge histogramme
  R03_age_groupes.png     — Groupes d'âge
  R04_imc.png             — IMC distribution
  R05_imc_categories.png  — IMC catégories
  R06_asa_pie.png         — ASA pie chart
  R07_asa_age.png         — Âge moyen par ASA
  R08_specialite.png      — Spécialité
  R09_anesthesie.png      — Anesthésie
  R10_distribution_jeune.png  — Distribution jeûne
  R11_boxplots_jeune.png  — Boxplots
  R12_jeune_par_specialite.png — Jeûne par spécialité
  R13_instructions.png    — Instructions
  R14_source_instructions.png — Source
  R15_retard_donut.png    — Donut retard
  R16_retard_distribution.png — Distribution retard
  R17_retard_specialite.png   — Retard par spécialité
  R18_violin_jeune_retard.png — Violin plot
  R19_comparaison_recommandations.png — Comparaison
  R20_heatmap.png         — Heatmap viridis

06_Donnees/
  └── data_clean.csv
        Données nettoyées et standardisées prêtes à l'analyse (195 patients)

==========================================================================
RÉSULTATS CLÉS
==========================================================================
  N = 195 patients | Sexe masculin : 60,0% | Âge moyen : 40,6 ± 21,5 ans
  Durée jeûne SOLIDE  : 9,38 ± 1,57h (recommandation : ≤ 6h)
  Durée jeûne LIQUIDE : 9,23 ± 1,65h (recommandation : ≤ 2h)
  Solide > 6h : 97,4% | Liquide > 2h : 100%
  Retard chirurgical : 48,7% | Association retard × jeûne : p < 0,001
==========================================================================
